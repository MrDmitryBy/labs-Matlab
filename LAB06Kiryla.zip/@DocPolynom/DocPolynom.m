classdef DocPolynom
    %DOCPOLYNOM Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        coef
    end
    
    methods
        function obj = DocPolynom(c)
            %DOCPOLYNOM Construct an instance of this class
            %   Detailed explanation goes here
            if nargin > 0
                if isa(c,'DocPolynom')
                    obj.coef = c.coef;
                else
                    obj.coef = c(:).';
                end
            elseif nargin == 0
                obj.coef = [];
            end
        end
        
        function obj = set.coef(obj,val)
            %METHOD1 Summary of this method goes here
            %   Detailed explanation goes here
            if ~isa(val, 'double')
                error('Coefficients must be be doubles')
            end
            ind = find(val(:).'~=0);
            if ~isempty(ind)
                obj.coef = val(ind(1):end);
            else
                obj.coef = val;
            end
        end
    end
end

