function y = polyval(p,x)
% POLYNOM/POLYVAL POLYVAL(p,x) evaluates p at the points x.
    y=0;
    for a = p.coef
        y = y.*x + a;
    end
end