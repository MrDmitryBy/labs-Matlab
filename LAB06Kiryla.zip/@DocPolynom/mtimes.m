function r = mtimes(p,q)
% POLYNOM/MTIMES Implement p * q for polynoms.
    p = DocPolynom(p);
    q = DocPolynom(q);
    r = DocPolynom(conv(p.coef,q.coef));
end
