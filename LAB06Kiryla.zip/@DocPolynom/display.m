function display(p)
% POLYNOM/DISPLAY Command window display of a polynom
    disp(' ');
    disp([inputname(1), ' = '])
    disp(' ');
    disp([' ' char(p)])
    disp(' ');
end
    