function q = diff(p)
% POLYNOM/DIFF DIFF(p) is the derivative of the polynom p.
    coef = p.coef;
    d = length(coef)-1;
    q = DocPolynom(p.coef(1:d).*(d:-1:1));
end