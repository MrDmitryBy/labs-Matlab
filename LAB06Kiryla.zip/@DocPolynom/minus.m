function r = minus(p,q)
% POLYNOM/MINUS Implement p - q for polynoms.
    p = DocPolynom(p);
    q = DocPolynom(q);
    k = length(q.coef) - length(p.coef);
    r = DocPolynom([zeros(1,k) p.coef] - [zeros(1,-k) q.coef]);
end